extends PanelContainer

@onready var label = $MarginContainer/Label

var card_data = {}
var is_black_card := false

var original_z = 0
var original_pos = Vector2.ZERO
var original_scale = Vector2.ONE

func _ready():
	label = $MarginContainer/Label
	
	# guardar estado original
	original_z = z_index
	original_pos = position
	original_scale = scale

	# importante para detectar mouse
	mouse_filter = Control.MOUSE_FILTER_STOP


func setup(data: Dictionary, black := false):
	card_data = data
	is_black_card = black

	if label:
		label.text = data.get("text", "")

	call_deferred("_apply_data")


func update_style():
	if label == null:
		push_error("Label no inicializado todavía")
		return

	var style = StyleBoxFlat.new()

	style.set_corner_radius_all(24)
	style.shadow_color = Color(0, 0, 0, 0.3)
	style.shadow_size = 8

	if is_black_card:
		style.bg_color = Color(0.08, 0.08, 0.08)
		label.add_theme_color_override("font_color", Color.WHITE)
	else:
		style.bg_color = Color.WHITE
		label.add_theme_color_override("font_color", Color.BLACK)

	add_theme_stylebox_override("panel", style)


func _apply_data():
	if label == null:
		push_error("Label no listo en _apply_data")
		return

	label.text = card_data.get("text", "")
	update_style()


# 🔥 HOVER (LO IMPORTANTE)

func _on_mouse_entered():
	# subir la carta encima de todas
	z_index = 999
	get_parent().move_child(self, -1)  # asegura que quede arriba

	# efecto visual
	scale = Vector2(1.15, 1.15)
	position.y -= 30


func _on_mouse_exited():
	# volver a normal
	z_index = original_z
	scale = original_scale
	position = original_pos
