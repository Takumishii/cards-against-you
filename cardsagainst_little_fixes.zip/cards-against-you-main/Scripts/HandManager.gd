extends Node

@onready var hand_container = $"../Hand"

var card_scene = preload("res://Scenes/card.tscn")

var hand = []

# Ajustes del abanico
@export var spread := 60.0
@export var curve := 12.0

func _ready():
	draw_hand()


func draw_hand():
	for i in range(7):
		add_card()


func add_card():
	var card_data = CardDatabase.get_random_white()
	hand.append(card_data)

	var new_card = card_scene.instantiate()
	new_card.setup(card_data, false)

	hand_container.add_child(new_card)

	update_hand_layout()
	
func update_hand_layout():
	var n = hand_container.get_child_count()
	if n == 0:
		return

	var center_x = hand_container.size.x / 2
	var base_y = hand_container.size.y * 0.85

	var spacing = 40.0   # separación horizontal real
	var tilt = 30.0       # inclinación (como cartas reales)
	var lift = 25.0       # leve elevación en el centro

	for i in range(n):
		var card = hand_container.get_child(i)

		var t = float(i) / (n - 1) if n > 1 else 0.5
		t = t * 2.0 - 1.0  # [-1, 1]

		# ✅ POSICIÓN HORIZONTAL (esto manda el efecto real)
		var x = center_x + t * spacing * (n - 1) * 0.5

		# ✅ LEVANTAR SOLO EL CENTRO (muy suave)
		var y = base_y - (1.0 - abs(t)) * lift

		# ✅ OFFSET carta
		var offset = Vector2(card.size.x / 2, card.size.y)

		card.position = Vector2(x, y) - offset

		# ✅ ROTACIÓN (esto da el efecto abanico REAL)
		card.rotation_degrees = t * tilt

		# ✅ ORDEN
		card.z_index = i
